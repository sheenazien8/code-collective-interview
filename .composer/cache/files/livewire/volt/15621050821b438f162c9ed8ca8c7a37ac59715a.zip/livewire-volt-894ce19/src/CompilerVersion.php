<?php

namespace Livewire\Volt;

class CompilerVersion
{
    /**
     * The current version of the Volt's compiler.
     */
    public const NUMBER = 3;
}
